package com.example.acae30.modelos

data class InventarioUnidades(
    var Id:Int?,
    var Id_inventario:Int?,
    var Equivale:Float?,
    var Unidades:String?
)