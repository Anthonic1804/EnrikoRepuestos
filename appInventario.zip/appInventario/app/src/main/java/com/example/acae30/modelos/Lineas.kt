package com.example.acae30.modelos

data class Lineas(
    var Id:Int?,
    var Nombre:String?,
    var Mayoreo_detalle:Char?
)