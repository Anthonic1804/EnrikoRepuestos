package com.example.acae30.modelos.JSONmodels

data class virtualCliente (
    var  Id:Int?,
    var Codigo:String?,
    var Cliente:String?,
    var Direccion:String?
)