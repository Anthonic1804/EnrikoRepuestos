package com.example.acae30.modelos.JSONmodels

data class LoginComprobar(val Usuario:String)