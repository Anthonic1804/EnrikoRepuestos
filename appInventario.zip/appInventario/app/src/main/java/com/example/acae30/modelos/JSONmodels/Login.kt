package com.example.acae30.modelos.JSONmodels

data class Login(val Usuario:String,val Clave:String,val Identidad:String)