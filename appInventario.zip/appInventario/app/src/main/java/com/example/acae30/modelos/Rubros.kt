package com.example.acae30.modelos

data class Rubros (
    var Id:Int?,
    var Rubro:String?,
    var Tipo:String?
)