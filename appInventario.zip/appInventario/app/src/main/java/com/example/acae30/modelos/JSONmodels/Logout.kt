package com.example.acae30.modelos.JSONmodels

data class Logout(val Usuario:String, val Identidad:String)